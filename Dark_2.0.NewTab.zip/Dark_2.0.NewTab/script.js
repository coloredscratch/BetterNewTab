/**
 * Dark Custom New Tab - Logic File
 * Handles Search Operators and Background Image Switching
 */

const initNewTab = () => {
    const bubble = document.getElementById('bubbleWrap');
    const trigger = document.getElementById('dropTrigger');
    const searchForm = document.getElementById('searchForm');
    const fileExtInput = document.getElementById('fileExtInput');
    
    // Background Image Elements
    const bgInput = document.getElementById('bgInput');
    const customizeBtn = document.getElementById('customizeBtn');
    const defaultBgUrl = 'theme_ntp_background.png';

    const getBoolSetting = (key, defaultVal) => {
        const val = localStorage.getItem(key);
        if (val === null) return defaultVal;
        return val === 'true';
    };

    const status = document.getElementById('appearanceStatus');
    const modeButton = document.getElementById('darkModeToggle');
    const tintToggle = document.getElementById('tintToggle');
    let statusTimer, clearStatusTimer;
    const report = (message = '', persistent = false) => {
        clearTimeout(statusTimer);
        clearTimeout(clearStatusTimer);
        status.textContent = message;
        status.classList.toggle('visible', Boolean(message));
        if (message && !persistent) statusTimer = setTimeout(() => {
            status.classList.remove('visible');
            clearStatusTimer = setTimeout(() => { status.textContent = ''; }, 250);
        }, 2000);
    };
    let currentUrl;
    let revision = 0;
    const database = new Promise((resolve, reject) => {
        const request = indexedDB.open('newTabAppearance', 1);
        request.onupgradeneeded = () => request.result.createObjectStore('images');
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
    });
    database.catch(() => {});
    const imageStore = async (action, value) => {
        const db = await database;
        return new Promise((resolve, reject) => {
            const transaction = db.transaction('images', action === 'get' ? 'readonly' : 'readwrite');
            const store = transaction.objectStore('images');
            const request = action === 'put' ? store.put(value, 'wallpaper') : store[action]('wallpaper');
            transaction.oncomplete = () => resolve(request.result);
            transaction.onerror = () => reject(transaction.error);
            transaction.onabort = () => reject(transaction.error);
        });
    };
    const decodeImage = (url) => new Promise((resolve, reject) => {
        const image = new Image();
        image.onload = () => resolve(image);
        image.onerror = () => reject(new Error('Cannot open image'));
        image.src = url;
    });
    const applyBackground = async (source, version) => {
        const url = source instanceof Blob ? URL.createObjectURL(source) : source;
        try {
            const image = await decodeImage(url);
            if (version !== revision) return;
            document.body.style.backgroundImage = 'url("' + url + '")';
            if (currentUrl) URL.revokeObjectURL(currentUrl);
            currentUrl = source instanceof Blob ? url : undefined;
            const canvas = document.createElement('canvas');
            canvas.width = canvas.height = 48;
            const context = canvas.getContext('2d', { willReadFrequently: true });
            context.drawImage(image, 0, 0, 48, 48);
            const pixels = context.getImageData(0, 0, 48, 48).data;
            // Alpha-weighted average, rather than the most common color bucket.
            const totals = [0, 0, 0];
            let weight = 0;
            for (let i = 0; i < pixels.length; i += 4) {
                const alpha = pixels[i + 3] / 255;
                for (let c = 0; c < 3; c++) totals[c] += pixels[i + c] * alpha;
                weight += alpha;
            }
            const rgb = weight ? totals.map(value => value / weight) : [120, 150, 180];
            // Keep more of the wallpaper hue in the glass, with a lighter switch accent.
            const light = rgb.map(value => Math.round(value * 0.55 + 255 * 0.45));
            const accent = rgb.map(value => Math.round(value * 0.30 + 255 * 0.70));
            document.documentElement.style.setProperty('--wallpaper-light', light.join(', '));
            document.documentElement.style.setProperty('--wallpaper-accent', accent.join(', '));
            // Check both black and white backdrops beneath the translucent glass.
            // Increase opacity only as needed so text remains readable anywhere on the image.
            const luminance = (color) => color.reduce((sum, channel, index) => {
                const value = channel / 255;
                return sum + (value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4)
                    * [0.2126, 0.7152, 0.0722][index];
            }, 0);
            let opacity = 0.75;
            let textColor;
            for (; opacity <= 1.001; opacity += 0.01) {
                const darkest = luminance(light.map(channel => channel * opacity));
                const brightest = luminance(light.map(channel => channel * opacity + 255 * (1 - opacity)));
                const darkContrast = (darkest + 0.05) / (luminance([17, 17, 17]) + 0.05);
                const whiteContrast = 1.05 / (brightest + 0.05);
                textColor = darkContrast >= whiteContrast ? '#111111' : '#ffffff';
                if (Math.max(darkContrast, whiteContrast) >= 4.5) break;
            }
            document.documentElement.style.setProperty('--tint-text', textColor);
            document.documentElement.style.setProperty('--tint-opacity', Math.min(opacity, 1).toFixed(2));
        } finally {
            if (source instanceof Blob && url !== currentUrl) URL.revokeObjectURL(url);
        }
    };
    const loadBackground = async () => {
        const version = revision;
        try {
            let saved = await imageStore('get');
            const legacy = localStorage.getItem('customBackground');
            if (!saved && legacy) {
                saved = await (await fetch(legacy)).blob();
                await imageStore('put', saved);
                localStorage.removeItem('customBackground');
            }
            await applyBackground(saved || defaultBgUrl, version);
        } catch {
            report('Could not load the saved wallpaper. Try choosing it again.');
            await applyBackground(localStorage.getItem('customBackground') || defaultBgUrl, version).catch(() => {});
        }
    };
    const applyMode = (light) => {
        document.documentElement.dataset.theme = light ? 'light' : 'dark';
        modeButton.checked = !light;
        tintToggle.disabled = !light;
    };
    applyMode(localStorage.getItem('appearanceMode') === 'light');
    modeButton.addEventListener('change', () => {
        const light = !modeButton.checked;
        applyMode(light);
        try { localStorage.setItem('appearanceMode', light ? 'light' : 'dark'); }
        catch { report('The mode changed, but could not be saved.'); }
    });
    tintToggle.checked = getBoolSetting('wallpaperTint', false);
    document.documentElement.dataset.tint = String(tintToggle.checked);
    tintToggle.addEventListener('change', () => {
        document.documentElement.dataset.tint = String(tintToggle.checked);
        try { localStorage.setItem('wallpaperTint', String(tintToggle.checked)); }
        catch { report('The color preference could not be saved.'); }
    });
    loadBackground();

    const settings = {
        ai: localStorage.getItem('aiEnabled') !== 'false', 
        exact: getBoolSetting('exactEnabled', false),
        reddit: getBoolSetting('redditEnabled', false),
        fileEnabled: getBoolSetting('fileEnabled', false),
        fileType: localStorage.getItem('lastFileType') || 'pdf'
    };

    const toggles = {
        ai: document.getElementById('aiToggleCheckbox'),
        exact: document.getElementById('verbatimToggle'),
        reddit: document.getElementById('pastYearToggle'),
        file: document.getElementById('imagesToggle')
    };

    // Initialize UI State
    if (toggles.ai) toggles.ai.checked = settings.ai;
    if (toggles.exact) toggles.exact.checked = settings.exact;
    if (toggles.reddit) toggles.reddit.checked = settings.reddit;
    if (toggles.file) toggles.file.checked = settings.fileEnabled;
    if (fileExtInput) fileExtInput.value = settings.fileType;

    const updateSetting = (key, value) => {
        settings[key] = value;
        const storageKey = key === 'fileType' ? 'lastFileType' : key === 'fileEnabled' ? 'fileEnabled' : key + 'Enabled';
        localStorage.setItem(storageKey, value.toString());
    };

    // Listeners
    toggles.ai?.addEventListener('change', function() { updateSetting('ai', this.checked); });
    toggles.exact?.addEventListener('change', function() { updateSetting('exact', this.checked); });
    toggles.reddit?.addEventListener('change', function() { updateSetting('reddit', this.checked); });
    toggles.file?.addEventListener('change', function() { updateSetting('fileEnabled', this.checked); });
    
    fileExtInput?.addEventListener('input', function() {
        updateSetting('fileType', this.value.trim().toLowerCase());
    });

    const customizeMenu = document.getElementById('customizeMenu');
    const uploadButton = document.getElementById('uploadBtn');
    const resetButton = document.getElementById('resetBtn');
    let menuOpen = false;
    const setMenuOpen = (open) => {
        menuOpen = open;
        customizeMenu.classList.toggle('is-open', open);
        customizeMenu.inert = !open;
        customizeMenu.setAttribute('aria-hidden', String(!open));
        customizeBtn.setAttribute('aria-expanded', String(open));
    };
    customizeBtn.addEventListener('click', () => setMenuOpen(!menuOpen));
    uploadButton.addEventListener('click', () => bgInput.click());
    document.addEventListener('click', (e) => {
        if (!customizeMenu.contains(e.target) && !customizeBtn.contains(e.target)) setMenuOpen(false);
    });
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && menuOpen) {
            setMenuOpen(false);
            customizeBtn.focus();
        }
    });
    const setWallpaperBusy = (busy) => {
        customizeBtn.disabled = uploadButton.disabled = resetButton.disabled = busy;
    };

    const resetWallpaper = async (e) => {
        e.preventDefault();
        if (customizeBtn.disabled) return;
        setWallpaperBusy(true);
        try {
            await imageStore('delete');
            localStorage.removeItem('customBackground');
            await applyBackground(defaultBgUrl, ++revision);
            report('Default wallpaper restored.');
        } catch { report('Could not reset the wallpaper. Please try again.'); }
        finally { setWallpaperBusy(false); }
    };
    customizeBtn.addEventListener('contextmenu', resetWallpaper);
    resetButton.addEventListener('click', resetWallpaper);
    bgInput?.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        setWallpaperBusy(true);
        report('Saving wallpaper…', true);
        const preview = URL.createObjectURL(file);
        try {
            await decodeImage(preview);
            await imageStore('put', file);
            localStorage.removeItem('customBackground');
            await applyBackground(file, ++revision);
            report('Wallpaper saved.');
        } catch {
            report('Could not save this wallpaper. Try a smaller image or another format.');
        } finally {
            URL.revokeObjectURL(preview);
            setWallpaperBusy(false);
            bgInput.value = '';
        }
    });

    // Dropdown Logic
    const handleToggleDropdown = (e) => {
        e.preventDefault();
        e.stopPropagation();
        bubble?.classList.toggle('active');
        trigger.setAttribute('aria-expanded', String(bubble.classList.contains('active')));
    };

    if (trigger) {
        trigger.addEventListener('click', handleToggleDropdown);
    }

    document.addEventListener('click', (e) => {
        if (bubble && bubble.classList.contains('active') && !bubble.contains(e.target)) {
            bubble.classList.remove('active');
            trigger.setAttribute('aria-expanded', 'false');
        }
    });

    searchForm?.addEventListener('submit', function(e) {
        const input = document.getElementById('searchInput');
        if (!input) return;

        let query = input.value.trim();
        if (query === "") {
            e.preventDefault();
            return;
        }

        // Handle URL parameters for AI avoidance
        // We remove existing udm inputs to avoid duplicates
        const existingUdm = searchForm.querySelector('input[name="udm"]');
        if (existingUdm) existingUdm.remove();

        if (toggles.ai && !toggles.ai.checked) {
            const udmInput = document.createElement('input');
            udmInput.type = 'hidden';
            udmInput.name = 'udm';
            udmInput.value = '14';
            searchForm.appendChild(udmInput);
        }

        let modifiedQuery = query;
        if (toggles.exact?.checked) modifiedQuery = `"${modifiedQuery}"`;
        if (toggles.reddit?.checked) modifiedQuery += " site:reddit.com";
        if (toggles.file?.checked) {
            const ext = fileExtInput.value.trim() || 'pdf';
            modifiedQuery += ` filetype:${ext}`;
        }

        input.value = modifiedQuery;
        
        // Restore visual query after a short delay so user doesn't see the operators in the box
        setTimeout(() => { if (input) input.value = query; }, 500);
    });
};

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initNewTab);
} else {
    initNewTab();
}
