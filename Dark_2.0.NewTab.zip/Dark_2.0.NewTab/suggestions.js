// Google suggestions stay separate from search operators and never inject HTML.
(() => {
    const input = document.getElementById('searchInput');
    const list = document.getElementById('suggestions');
    const form = document.getElementById('searchForm');
    const toggle = document.getElementById('suggestionsToggle');
    const container = document.querySelector('.main-container');
    let enabled = localStorage.getItem('suggestionsEnabled') !== 'false';
    toggle.checked = enabled;
    let history = [];
    try {
        const saved = JSON.parse(localStorage.getItem('recentSearches') || '[]');
        if (Array.isArray(saved)) history = [...new Set(saved.filter(value => typeof value === 'string' && value.trim()))].slice(0, 3);
    } catch { /* Ignore invalid history. */ }
    let open = false;
    let timer, controller;
    let generation = 0;
    let selected = -1;
    let typedQuery = '';
    let suggestions = [];
    let composing = false;
    const cache = new Map();

    const cancelRequest = () => {
        clearTimeout(timer);
        controller?.abort();
        generation++;
    };
    const setOpen = (value) => {
        open = value;
        list.classList.toggle('is-open', value);
        container.classList.toggle('suggestions-open', value);
        list.inert = !value;
        list.setAttribute('aria-hidden', String(!value));
        input.setAttribute('aria-expanded', String(value));
    };
    const close = () => {
        cancelRequest();
        setOpen(false);
        selected = -1;
        input.setAttribute('aria-expanded', 'false');
        input.removeAttribute('aria-activedescendant');
    };
    const choose = (value) => {
        input.value = value;
        close();
        form.requestSubmit();
    };
    const render = (values, recent = false) => {
        suggestions = values;
        selected = -1;
        list.replaceChildren();
        input.removeAttribute('aria-activedescendant');
        values.forEach((value, index) => {
            const item = document.createElement('li');
            item.id = 'suggestion-' + index;
            item.className = recent ? 'suggestion recent-search' : 'suggestion';
            item.setAttribute('role', 'option');
            item.setAttribute('aria-selected', 'false');
            item.textContent = value;
            item.addEventListener('mousedown', (event) => event.preventDefault());
            item.addEventListener('click', () => choose(value));
            list.appendChild(item);
        });
        list.setAttribute('aria-label', recent ? 'Recent searches' : 'Search suggestions');
        setOpen(values.length > 0);
    };
    const schedule = () => {
        cancelRequest();
        selected = -1;
        input.removeAttribute('aria-activedescendant');
        [...list.children].forEach(item => item.setAttribute('aria-selected', 'false'));
        typedQuery = input.value;
        const query = typedQuery.trim();
        if (!enabled || composing) { close(); return; }
        if (!query) { render(history, true); return; }
        const version = generation;
        timer = setTimeout(async () => {
            if (version !== generation || document.activeElement !== input) return;
            if (cache.has(query)) { render(cache.get(query)); return; }
            const request = new AbortController();
            controller = request;
            const timeout = setTimeout(() => request.abort(), 4000);
            try {
                const url = new URL('https://suggestqueries.google.com/complete/search');
                url.search = new URLSearchParams({ client: 'firefox', q: query });
                const response = await fetch(url, { signal: request.signal, credentials: 'omit' });
                if (!response.ok) throw new Error('Suggestions unavailable');
                const data = await response.json();
                const values = Array.isArray(data[1])
                    ? [...new Set(data[1].filter(value => typeof value === 'string' && value.trim()))].slice(0, 6)
                    : [];
                if (version !== generation || document.activeElement !== input) return;
                if (cache.size >= 50) cache.delete(cache.keys().next().value);
                cache.set(query, values);
                render(values);
            } catch {
                // Search continues to work normally when offline or suggestions fail.
                if (version === generation) close();
            } finally { clearTimeout(timeout); }
        }, 180);
    };
    input.addEventListener('input', schedule);
    input.addEventListener('focus', schedule);
    input.addEventListener('click', () => { if (!open) schedule(); });
    input.addEventListener('compositionstart', () => { composing = true; close(); });
    input.addEventListener('compositionend', () => { composing = false; schedule(); });
    input.addEventListener('keydown', (event) => {
        if (event.isComposing || composing) return;
        if (event.key === 'Escape') {
            if (open) { input.value = typedQuery; event.preventDefault(); }
            close();
        } else if (open && ['ArrowDown', 'ArrowUp'].includes(event.key)) {
            event.preventDefault();
            const count = suggestions.length;
            selected = event.key === 'ArrowDown'
                ? (selected + 1) % count : (selected <= 0 ? count - 1 : selected - 1);
            [...list.children].forEach((item, index) => item.setAttribute('aria-selected', String(index === selected)));
            input.value = suggestions[selected];
            input.setAttribute('aria-activedescendant', list.children[selected].id);
            list.children[selected].scrollIntoView({ block: 'nearest' });
        } else if (event.key === 'Enter' && open && selected >= 0) {
            event.preventDefault();
            choose(suggestions[selected]);
        } else if (event.key === 'Tab') close();
    });
    input.addEventListener('blur', close);
    document.addEventListener('click', (event) => { if (!form.contains(event.target)) close(); });
    // Capture runs before the main submit handler adds search operators.
    form.addEventListener('submit', () => {
        const query = input.value.trim();
        if (query) {
            history = [query, ...history.filter(value => value !== query)].slice(0, 3);
            try { localStorage.setItem('recentSearches', JSON.stringify(history)); } catch { /* Search still works. */ }
        }
        close();
    }, true);
    toggle.addEventListener('change', () => {
        enabled = toggle.checked;
        try { localStorage.setItem('suggestionsEnabled', String(enabled)); } catch { /* Apply for this tab. */ }
        if (!enabled) { cache.clear(); close(); }
    });
    setOpen(false);
})();
